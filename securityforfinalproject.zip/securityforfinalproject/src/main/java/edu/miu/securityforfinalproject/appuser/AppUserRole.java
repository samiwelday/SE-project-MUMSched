package edu.miu.securityforfinalproject.appuser;

public enum AppUserRole { USER,
    ADMIN
}
