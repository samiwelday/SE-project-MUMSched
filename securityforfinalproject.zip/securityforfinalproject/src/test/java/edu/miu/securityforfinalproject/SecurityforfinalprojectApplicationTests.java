package edu.miu.securityforfinalproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityforfinalprojectApplicationTests {

    @Test
    void contextLoads() {
    }

}
